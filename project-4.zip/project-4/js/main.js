$(document).ready(function() {
    $(".vidplay").magnificPopup( {
        type : 'iframe',
        iframe: {
            markup: '<div class="mfp-iframe-scaler">'+
                      '<div class="mfp-close"></div>'+
                      '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
                    '</div>',
          
            patterns: {
              youtube: {
                index: 'youtube.com/',
          
                id: 'v=',
          
                src: 'https://www.youtube.com/embed/%id%?autoplay=1'
              },
              vimeo: {
                index: 'vimeo.com/',
                id: '/',
                src: 'https://player.vimeo.com/video/%id%?autoplay=1'
              },
              gmaps: {
                index: 'https://maps.google.',
                src: '%id%&output=embed'
              }
          
          
            },
          
            srcAction: 'iframe_src',
          }
    });

});

$(document).ready(function() {
  $('.popup-img').magnificPopup({
    type:'image'
    
  });
});

$(document).ready(function() {
  $('.gallery-pic').magnificPopup({
    type:'image',
    gallery:{
      enabled:true
    }
    
  });
});

$(document).ready(function() {
    AOS.init({
      offset: 300,
      duration: 1000
    });
});

// $(document).ready(function() {(
//   mybutton = document.getElementById("myBtn");

  
//   window.onscroll = function() {scrollFunction()};

//   function scrollFunction() {
//     if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
//       mybutton.style.display = "block";
//     } else {
//       mybutton.style.display = "none";
//     }
//   }

  
//   function topFunction() {
//     document.body.scrollTop = 0;
//     document.documentElement.scrollTop = 0;
//   };
// });



